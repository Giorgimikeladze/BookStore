﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
	public class Person
	{
		[Key]
		public int Id { get; set; }

		[Required]
		public string Name { get; set; }


		[Required]
		public int Age { get; set; }

		
		public DateTime DateOfBirth { get; set; }



		public Person()
		{

		}

		public Person(int id,string name,int age)
		{

			Id = id;
			Name = name;
			Age = age;


		}

		public Person(int id, string name, int age,DateTime Birt):this(id,name,age)
		{
			DateOfBirth= Birt;

		}

	}
}
