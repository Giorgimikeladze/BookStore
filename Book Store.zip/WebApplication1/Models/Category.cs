﻿using System.ComponentModel.DataAnnotations;
using WebApplication1.Controllers;

namespace WebApplication1.Models
{
    public class Category
    {

        [Key]
        public int ID { get; set; }

        [Required]
        public string Name { get; set; }

        public string Displayorder { get; set; }

        public DateTime CreadDateTime { get; set;    } = DateTime.Now;

       
    }
}
