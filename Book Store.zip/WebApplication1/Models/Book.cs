﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
	public class Book
	{
		[Key]
		public int Id { get; set; }
		[Required]
		public string Name { get; set; }

		[Required]
		public string AutorName { get; set; }

		[Required]
		public double Price { get; set; }



		public string Description { get; set; }

		public string Img { get; set; }


		public DateTime ReleaseDate { get; set; }=DateTime.Now;


	}
}
