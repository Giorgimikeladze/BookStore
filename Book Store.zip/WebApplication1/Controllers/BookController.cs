﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.Operations;
using Microsoft.CodeAnalysis.VisualBasic.Syntax;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Data;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
	public class BookController : Controller
	{
		private readonly ApplicationDbContext _db;

		public BookController(ApplicationDbContext db)
		{
			_db = db;



		}

        public static List<int> Cart_Items_ID = new List<int>();


        public IActionResult Index(int Id)
		{

			var book = _db.Books.FirstOrDefault(b => b.Id == Id);

			if (book == null)
			{
				return NotFound();
			}


			return View(book);
		}


		//GET
		public IActionResult Create() {


			return View();

		}


		//POST
		[HttpPost]
		[ValidateAntiForgeryToken]
		public IActionResult Create(Book obj) {





			_db.Books.Add(obj);
			_db.SaveChanges();

			return RedirectToAction("Index", "Home");

		}


		//GET
		public IActionResult Edit(int ID) {


			var book = _db.Books.FirstOrDefault(u => u.Id == ID);



			return View(book);
		}

		//POST
		[HttpPost]
		[ValidateAntiForgeryToken]
		public IActionResult Edit(Book obj)
		{





			_db.Books.Update(obj);
			_db.SaveChanges();

			return RedirectToAction("Index", "Home");

		}


		//GET
		public IActionResult Delete(int ID)
		{


			var book = _db.Books.Find(ID);
			if (book != null) {
				_db.Books.Remove(book);
				_db.SaveChanges();
				return RedirectToAction("Index", "Home");
			}
			else {

				return NotFound(ModelState);
			}


		}

		////POST
		//[HttpPost]
		//[ValidateAntiForgeryToken]
		//public IActionResult Delete(Book obj)
		//{

		//    _db.Books.Remove(obj);
		//    _db.SaveChanges();

		//    return RedirectToAction("Index", "Home");

		//}

			public IActionResult AddToCart(int id) {


				Cart_Items_ID.Add(id);


			return RedirectToAction("Index", "Home");



		
			}

		public IActionResult Cart() { 
		
		
			List<Book>booksincart=new List<Book>();

			foreach (int temp in Cart_Items_ID) { 
			
				var tempbook=_db.Books.Find(temp);
				booksincart.Add(tempbook);

			}


			

			return View(booksincart);
		}


		public IActionResult DeleteFromCart(int id) {


            Cart_Items_ID.Remove(id);



            return RedirectToAction("Cart","Book");
		
		}
    }


	

}
