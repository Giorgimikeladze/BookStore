﻿namespace WebApplication1.Controllers
{
    public static class Data
    {
        //public static List<int> Cart_Items_ID = new List<int>();


    }
}
